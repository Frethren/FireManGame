Hello Everyone
Thank you for downloading my 3d model.
I created the models with 3ds Max. They have been tested in Unity and they work perfectly.
Package includes 2 lane roads, 4 lane roads, intersections, elevated expressways, and elevated expressway ramps.

Textures are modified. Credits go to www.mb3d.co.uk for the sidewalk and bgfons.com for the asphalt.
Enjoy!